UNOFFICIAL TEMPORAL FORK [SBCL-WIN32-THREADS] SPECIFIC NOTES

Project home: http://github.com/akovalenko/sbcl-win32-threads
NEWS:
* Fixed issue #8 in external build scripts: x86-64 MSI build now includes ASDF.
* Prebuilt binaries: make :qslime REPL extension work again after 2011-11-27 SLIME update.

